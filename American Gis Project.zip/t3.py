import geopandas as gpd
import rasterio
import matplotlib.pyplot as plt
import numpy as np
from pathlib import Path
import pandas as pd
import numpy as np
from scipy.stats import pearsonr
import seaborn as sns
import glob
import rasterio
import matplotlib.pyplot as plt
tiff_files = glob.glob('C:/python task/covariates/' + '*.tif')
project_boundary_gpkg_path = r"C:/python task\seqana_gis_solutions_eng_challenge_project_boundary.gpkg"
pre_sampled_gpkg_path = r"C:/python task\seqana_gis_solutions_eng_challenge_existing_sample_data.gpkg"
for i in tiff_files:
    with rasterio.open(i) as src:       
        raster_data = src.read(1)  
        plt.figure(figsize=(12, 8)) 
        plt.imshow(raster_data, cmap='rainbow')
        plt.colorbar(shrink=0.5) 
        plt.title(f'{Path(i).stem}')
        plt.xlabel('X')
        plt.ylabel('Y')
        plt.savefig(f'C:/python task/results/{Path(i).stem}.png')
gdf = gpd.read_file(pre_sampled_gpkg_path)
soc_stocks = gdf['soc_stock_t_ha']
mean_soc = soc_stocks.mean()
median_soc = soc_stocks.median()
std_soc = soc_stocks.std()
plt.figure(figsize=(10, 6))
plt.hist(soc_stocks, bins=30, edgecolor='black', color='skyblue')
plt.xlabel('SOC Stocks')
plt.ylabel('Frequency')
plt.title('Distribution of Soil Organic Carbon (SOC) Stocks')
plt.axvline(mean_soc, color='red', linestyle='dashed', linewidth=2, label='Mean')
plt.axvline(median_soc, color='green', linestyle='dashed', linewidth=2, label='Median')
plt.axvline(std_soc, color='yellow', linestyle='dashed', linewidth=2, label='standard daviation')
plt.legend()
plt.savefig(f'C:/python task/results/Distribution of Soil Organic Carbon (SOC) Stocks.png')
print(f"Mean SOC Stocks: {mean_soc:.2f}")
print(f"Median SOC Stocks: {median_soc:.2f}")
print(f"Standard Deviation of SOC Stocks: {std_soc:.2f}")   
project_boundary = gpd.read_file(project_boundary_gpkg_path)
soc_stocks = gdf['soc_stock_t_ha']
fig, ax = plt.subplots(figsize=(20, 16))
project_boundary.plot(ax=ax, color='lightgray', edgecolor='black')
gdf.plot(column='soc_stock_t_ha', cmap='plasma', markersize=100, legend=True, ax=ax)
plt.xlabel('Longitude')
plt.ylabel('Latitude')
plt.title('Map Visualization of SOC Stocks')
plt.savefig(f'C:/python task/results/map visualization of (SOC) Stocks.png')
def get_raster_value(point, raster_data, transform):
    row, col = rasterio.transform.rowcol(transform, point.x, point.y)
    return raster_data[row, col]
def get_rastervalue(tiff_file):
    with rasterio.open(tiff_file) as src:
        raster_data = src.read(1)  
        transform = src.transform
        gdf_points = gpd.read_file(pre_sampled_gpkg_path)    
        raster_value = gdf_points['geometry'].apply(get_raster_value, args=(raster_data, transform))
        raster_value = pd.DataFrame(raster_value).rename(columns={'geometry':f'{Path(tiff_file).stem}'})
        return raster_value
gdf_soc_values = gpd.read_file(pre_sampled_gpkg_path)
for i in tiff_files:
    gdf_soc_values = pd.concat([pd.DataFrame(gdf_soc_values),(get_rastervalue(i))] ,axis=1)
gdf_soc_values = gdf_soc_values.rename(columns={'CGIAR_SRTM90_V4':'SRTM90',
 'landsat7_c01_t1_annual_ndvi_2009':'ndvi',
 'modis_annual_npp_2009':'npp',
 'open_land_map_soil_clay':'clay',
 'open_land_map_soil_ph':'ph'})
output_csv_file = 'C:/python task/results/gdf_soc_values.csv'
gdf_soc_values.to_csv(output_csv_file, index=False)
gdf_soc_data = gdf_soc_values[['soc_stock_t_ha','ndvi','npp', 'clay', 'ph']]
gdf_soc_data.corr()



